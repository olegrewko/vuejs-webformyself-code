<template>
  <h1>Counter: {{ counter }}</h1>
</template>

<script>
export default {
  props: ['counter']
}
</script>
