<template>
  <div>
    <h2>Car</h2>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consectetur, voluptate.</p>
  </div>
</template>

<script>
export default {

}
</script>

<style scoped>
  div {
    border: 1px solid black;
  }
</style>
