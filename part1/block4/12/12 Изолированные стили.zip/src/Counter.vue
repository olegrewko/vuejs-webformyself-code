<template>
  <div>
    <h2>Counter</h2>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dicta, impedit.</p>
  </div>
</template>

<script>
export default {
}
</script>

<style scoped>
  h2 {
    color: red;
  }
</style>
