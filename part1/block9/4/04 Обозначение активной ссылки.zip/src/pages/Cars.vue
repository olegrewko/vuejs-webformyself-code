<template>
  <h1>Cars page</h1>
</template>

<script>
  export default {

  }
</script>

<style scoped>

</style>
