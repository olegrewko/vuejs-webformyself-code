<template>
    <h1 style="color: red;">404 Error</h1>
</template>

<script>
  export default {

  }
</script>

<style scoped>

</style>
