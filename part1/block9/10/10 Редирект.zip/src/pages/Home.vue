<template>
    <h1>Home page</h1>
</template>

<script>
  export default {

  }
</script>

<style scoped>

</style>
