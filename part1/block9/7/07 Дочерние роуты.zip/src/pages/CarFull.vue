<template>
    <div>
      <h4>Car name: Ford</h4>
      <h5>Car year: 2016</h5>
    </div>
</template>

<script>
  export default {
  }
</script>

<style scoped>

</style>
