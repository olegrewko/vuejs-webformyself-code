<template>
    <h2>Counter {{counter}}</h2>
</template>

<script>
  export default {
    props: ['counter']
  }
</script>

<style scoped>

</style>
