import './styles.css';

console.log('index.js');