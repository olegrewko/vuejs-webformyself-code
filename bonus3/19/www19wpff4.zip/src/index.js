console.log(1 + 6);
console.log('Hello');