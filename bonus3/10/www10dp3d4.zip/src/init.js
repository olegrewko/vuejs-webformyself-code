function init() {

    myJquery('body').html(VERSION);


}