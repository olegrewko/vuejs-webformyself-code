import * as noExport from './no-export';

console.log($);
console.log(noExport);