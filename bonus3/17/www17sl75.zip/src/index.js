alert(1);
console.warn('debug');
console.log('more debug');

var a = 1;
var b = 2;