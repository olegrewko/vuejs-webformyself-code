import logo from './img/webpack.png';

// console.log(logo);

let img = document.createElement('img');
img.setAttribute('src', logo);

document.body.appendChild(img);