import * as $ from 'jquery';

$('body').html('Webpack init with npm!');