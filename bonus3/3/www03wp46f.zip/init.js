import './a.js';
import './b.js';

console.log('./init');