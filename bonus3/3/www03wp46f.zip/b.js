import './c.js';
import './d.js';

console.log('b');