import './b.js';
import './c.js';

console.log('a.js');