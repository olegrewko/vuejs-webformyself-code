import action from './common/action';
import app from './common/app';

console.log('shop.js');

app();
action();