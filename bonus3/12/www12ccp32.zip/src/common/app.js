export default function app() {
    console.log('App!');
}