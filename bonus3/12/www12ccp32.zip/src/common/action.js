export default function action() {
    console.log('Action!');
}