import action from './common/action';
import app from './common/app';
import $ from 'jquery';
import _ from 'lodash';

$('body').html('Hello');
_.time();

console.log('index.js');
app();
action();