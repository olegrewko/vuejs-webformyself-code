import * as app from './components/application';
import * as item from './components/profile-item';

app.action();

console.log('You are on the Profile Page');

item.action();