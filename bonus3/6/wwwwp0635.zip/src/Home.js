import * as app from './components/application';

app.action();

console.log('You are on the Home Page');