export function action() {
    console.log('Application action');
}