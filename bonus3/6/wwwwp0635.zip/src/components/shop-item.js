export function action() {
    console.log('Shop item action');
}