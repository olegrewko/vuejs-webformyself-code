export function action() {
    console.log('Profile item action');
}