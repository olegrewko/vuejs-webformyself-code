import './a';
import './b';

console.log('init');