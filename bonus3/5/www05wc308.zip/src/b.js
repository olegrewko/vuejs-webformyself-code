import './c';
import './d';

console.log('b');