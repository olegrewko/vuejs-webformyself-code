<template>
  <h1>Hello Vue</h1>
</template>

<script>
export default {
}
</script>
