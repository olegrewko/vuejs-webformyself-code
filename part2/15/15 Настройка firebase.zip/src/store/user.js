export default {
  state: {
    user: null
  },
  mutations: {},
  actions: {},
  getters: {
    user (state) {
      return state.user
    }
  }
}
