let array = ['WFM', 30];

//let name = array[0];
//let age = array[1];
//let color = array[2];

let [, , color='red'] = array;

console.log(color);