import Car from './extra';

var car = new Car();