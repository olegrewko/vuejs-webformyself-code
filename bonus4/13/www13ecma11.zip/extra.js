export default class Car {
    constructor() {
        console.log('Car constructor!');
    }
}