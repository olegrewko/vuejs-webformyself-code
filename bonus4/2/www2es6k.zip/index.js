for (var i = 0; i < 5; i++) {
    setTimeout(function () {
        console.log(i);
    }, 3000);
}

const PI = 3.14;
let a = 1;