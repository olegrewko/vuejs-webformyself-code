let name = 'WFM';

//let str = 'Hello ' + name + ', glad to \'see\' you!';
//let str = `Hello ${name}, glad to "see" you! ${5 + 10}`;

let html = `
    <div>
        <h1>${name}</h1>
        <span>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quam, tempore.</p>
        </span>
    </div>
`;

console.log(html);