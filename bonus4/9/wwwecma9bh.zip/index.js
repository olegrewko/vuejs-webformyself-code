let array = [1, 2, 3, 4, 5];

//for (let i = 0; i < array.length; i++) {
//    console.log(array[i]);
//}

//array.forEach(function (item) {
//    console.log(item);
//});

//for (let item of array) {
//    console.log('Item: ', item);
//}

for (let item of 'ABCDEFG') {
    console.log('Item: ', item);
}