require('./car');

var bmw = new Car('BMW');
bmw.logName();