var lodash = require('lodash');

require('./a/a');

console.log(lodash.sum([4, 6]));