var _ = require('lodash');

console.log('this is a.js: ', _.sum(10, 30));