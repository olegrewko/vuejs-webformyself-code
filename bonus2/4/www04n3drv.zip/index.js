var _ = require('lodash');

console.log(_.sum([4, 6]));